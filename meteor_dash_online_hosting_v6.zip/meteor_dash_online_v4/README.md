# Meteor Dash Online — V4 Release Candidate

A browser-playable multiplayer development project for Meteor Dash. Includes survival race, private rooms, battle royale, guest and username/password accounts, a JSON-file profile/leaderboard store, a cosmetic coin shop, and a simulated reward button.

## Requirements
- Node.js 22 recommended
- npm

## Run locally
```bash
npm install
npm run check
npm start
```
Open `http://localhost:3000`. Health check: `http://localhost:3000/healthz`.

## Docker
```bash
docker build -t meteor-dash-online .
docker run --rm -p 3000:3000 -v meteor-dash-data:/app/data meteor-dash-online
```

## Critical limitations
This is not yet a production or app-store release. Apple/Google sign-in, real in-app purchases, real rewarded ads, production database, account recovery/deletion, and native iOS/Android packages are not implemented. The rewarded-ad button is simulated and coin packs are not purchasable. Do not enable real-money payments. The JSON file is single-instance development storage; production requires a managed database and additional security work.

Read `RELEASE_STATUS.md`, `LAUNCH_CHECKLIST.md`, `SETUP.md`, `PRIVACY_POLICY_TEMPLATE.md`, and `TERMS_TEMPLATE.md` before deployment.


## Online hosting
See `HOSTING_GUIDE.md` for deployment to Render. `render.yaml` defines a test service and persistent disk; cloud resources must be created from your own hosting account.
