# Meteor Dash Online — Launch readiness checklist

This repository is a **release candidate / self-hosted web prototype**, not a fully store-ready mobile game. Do not take real payments or claim production-grade security until the items below are completed and independently tested.

## Included in this build
- Guest and username/password account flows
- Guest upgrade to username/password account
- JSON-file saved profiles and leaderboard (single server instance only)
- Three multiplayer room modes
- Cosmetic shop using earned demo coins
- Simulated rewarded-ad button; no ad is actually served
- Product endpoint deliberately reports real payments as unconfigured
- Basic API request throttling, security response headers, `/healthz`, Dockerfile

## Required before public production launch

### Backend / security
- [ ] Replace `data.json` with managed PostgreSQL or another production database; configure backups and migrations.
- [ ] Replace in-memory sessions and room state with durable/session-store design; add expiry, logout, token rotation, and account recovery.
- [ ] Add HTTPS at hosting edge; verify secure proxy configuration.
- [ ] Add robust rate limiting backed by shared storage, CAPTCHA/abuse controls where appropriate, audit logging, and alerting.
- [ ] Add server-authoritative gameplay and score validation; test WebSocket abuse and concurrent joins.
- [ ] Add automated unit, integration, load, and security tests; conduct a security review.
- [ ] Set up monitoring, crash/error reporting, backups, restore tests, and a rollback plan.
- [ ] Add account deletion and data export/deletion workflow where required.

### Sign-in providers
- [ ] Apple: enroll in Apple Developer Program, configure Sign in with Apple identifiers/keys/redirect URLs, implement server-side token validation and nonce/state checks.
- [ ] Google: configure OAuth consent screen and OAuth client IDs, approved redirect URLs, implement server-side ID-token validation and state/nonce checks.
- [ ] Test provider sign-in on real iOS and Android devices. The current UI/API does not implement these providers.

### Purchases and advertising
- [ ] Define actual products in App Store Connect and Google Play Console.
- [ ] Integrate StoreKit and Google Play Billing (usually through a native wrapper or game engine plugin); verify signed transactions/receipts on the server.
- [ ] Make purchase grants idempotent; handle refunds, chargebacks, restore purchases, parental controls, and regional availability.
- [ ] Integrate a real rewarded-ad SDK; grant rewards only after a verified SDK reward callback/server-side verification. The current button is a demo reward and must not be represented as a real ad.
- [ ] Add age-appropriate ad settings, consent/privacy controls, and ad-network disclosures.

### Mobile release
- [ ] Decide the native implementation/wrapper (for example, Capacitor) and configure bundle/package IDs, icons, splash screens, orientation, safe areas, offline/error states, and deep links.
- [ ] Configure Apple/Google developer accounts, signing certificates, provisioning, app identifiers, and store listings.
- [ ] Test device sizes, touch input, poor network, reconnects, background/resume, accessibility, and crash-free sessions.
- [ ] Publish privacy policy and terms at publicly accessible HTTPS URLs; provide support contact and age/content ratings.
- [ ] Complete App Store privacy disclosures and Google Play Data safety forms accurately; submit for review.

### Legal / operations
- [ ] Review privacy policy and terms with qualified counsel for actual data collection, jurisdictions, ads, minors, and retention.
- [ ] Add support email, abuse reporting/moderation, community rules, and incident response contact.
- [ ] Confirm game name/trademarks and licenses for all art, music, fonts, and libraries.

## Local smoke test
1. `npm install`
2. `npm start`
3. Open `http://localhost:3000`
4. Confirm `http://localhost:3000/healthz` returns `{"ok":true,...}`
5. Create a guest profile, upgrade it to an account, log out by clearing browser local storage (logout endpoint is not yet implemented), and sign in again.
6. Test two browser windows joining a public room and a private room.
7. Buy/equip a cosmetic with demo coins; restart server and confirm data persists in a single-instance local setup.

## Important architecture limit
The JSON database and in-memory sessions/rooms are for development only. Do not run multiple replicas against the same JSON file. Production needs a real database and shared session/room infrastructure.
