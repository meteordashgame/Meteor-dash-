# Release status — Meteor Dash Online

**Status: Feature-complete development package; not production-ready and not published.**

No assistant can complete the external steps that require the owner's developer accounts, legal business/contact details, signing credentials, provider secrets, payment product setup, ad-network approval, hosting account, or device testing. Those are intentionally not fabricated or embedded in this project.

## Working in this code package
- Browser-playable canvas game with public survival and battle royale rooms, plus private room codes.
- Guest and username/password flows; guest upgrade; profile persistence in local JSON storage.
- Server-backed cosmetic coin shop and demo rewarded-ad endpoint.
- Best-score leaderboard stored by the server.
- Basic API throttling, security response headers, health endpoint, Docker build recipe, and launch documentation.

## Not implemented / cannot be claimed as complete
- Apple or Google identity provider sign-in: UI/provider credentials and server token validation remain to be implemented.
- Real App Store / Play Store billing and receipt verification.
- Real ads or verified ad rewards.
- Production database, durable shared sessions, scalable multiplayer hosting, account recovery/deletion, and full anti-cheat.
- Native iOS/Android app package, app signing, store metadata, and store review.
- Published legal policy: templates are provided but must be completed and reviewed for the real service.

## Before anyone spends money
Do not deploy this on a public production domain with real user accounts or payments until the production checklist is complete. The JSON database is not suitable for multi-instance deployment, and the in-memory multiplayer state is not horizontally scalable. Never put provider secrets or signing keys in client code or commit them to source control.
