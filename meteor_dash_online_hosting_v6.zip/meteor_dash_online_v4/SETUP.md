# Meteor Dash Online v3 — account and leaderboard setup

## Included in this build
- Guest play with a persistent guest identity in the browser.
- Username/password registration and login. Passwords are salted and hashed with Node.js `scrypt`; raw passwords are never written to the data file.
- Guest profile upgrade to a username/password account while retaining the same profile and progress.
- Persistent player profile fields: best score, games played, coins, and unlocked cosmetic IDs (starter placeholder).
- Persistent global top-score leaderboard.
- Existing Survival Race, private room codes, and Battle Royale multiplayer modes.
- Apple/Google sign-in UI placeholders with explicit setup messaging.

## Run locally
1. Install Node.js 18 or newer.
2. Unzip this project.
3. In the project directory, run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

The server writes player data to `data.json` in the project directory. Back up this file. For production, replace this simple JSON store with a managed database (for example PostgreSQL) and add migrations, backups, rate limits, email/password reset, account deletion, and privacy/terms pages.

## Apple and Google sign-in status
The buttons are intentionally not represented as functional OAuth yet. Real Sign in with Apple / Google requires registered app identifiers, provider credentials, verified redirect/callback URLs, secure OAuth state/nonce handling, and server-side token verification. Configure those in Apple Developer and Google Cloud Console, then implement provider callbacks before launch. Never put provider secrets in browser code.

## Important production limitations
- The demo's persistent JSON store is suitable for development, not a multi-instance production service.
- The multiplayer prototype accepts client movement coordinates and should not be treated as cheat-proof. Add authoritative movement/collision validation and rate limiting.
- Coins currently accrue as a demo progression counter. There is no purchase checkout, no real-money transaction, and no consumable-item inventory logic yet.
- Apple/Google in-app purchases and rewarded ads are not implemented. Mobile store billing must be added in native app builds, with server-side receipt verification.
- Leaderboard entries are based on server-tracked survival score when a player is hit, but production anti-cheat and abuse monitoring are still required.
- Sessions are long-lived demo bearer tokens stored in the browser. Production should use revocable/expiring sessions, HTTPS-only secure cookies where appropriate, CSRF protections, and account/session management.
- Do not deploy this prototype publicly with valuable purchases or sensitive user data until the production security work is complete.


## Monetization development build

The Galaxy Shop uses demo coins and server-side item ownership/equip endpoints. The “claim demo reward” button simulates a rewarded-ad payout (+50 coins, with a per-account 60-second cooldown); it is NOT an actual ad view and must not be represented as one in production. Real money purchases are intentionally disabled. Before launch, integrate Google Play Billing and Apple StoreKit (or a cross-platform billing provider), validate receipts/tokens on the server, handle refunds/revocations, and never grant paid currency from a client-only request. Keep cosmetic unlocks server-authoritative.

API additions: `GET /api/shop`, `POST /api/shop/buy`, `POST /api/shop/equip`, `POST /api/rewards/ad` (demo-only), and `GET /api/store-products` (returns not-configured). This prototype stores data in `data.json`; use a managed database for multi-instance hosting and backups.
