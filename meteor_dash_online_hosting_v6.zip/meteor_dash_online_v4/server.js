const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const WebSocket = require("ws");

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "0.0.0.0";
const TRUST_PROXY = process.env.TRUST_PROXY === "1";
const rateBuckets = new Map();
function rateLimit(req, res, limit=60, windowMs=60000) {
  const forwarded = TRUST_PROXY ? String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() : "";
  const ip = forwarded || req.socket.remoteAddress || "unknown";
  const key = `${ip}:${req.url.split("?")[0]}`; const now = Date.now(); let b = rateBuckets.get(key);
  if (!b || now >= b.until) b = { count: 0, until: now + windowMs }; b.count++; rateBuckets.set(key,b);
  if (rateBuckets.size > 10000) for (const [k,v] of rateBuckets) if (now >= v.until) rateBuckets.delete(k);
  if (b.count > limit) { json(res,429,{error:"Too many requests. Please try again shortly."}); return false; } return true;
}
const DB_FILE = process.env.DATA_FILE || path.join(__dirname, "data.json");
let db = { users: [], sessions: {}, leaderboard: [], rewardClaims: {} };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, "utf8")) }; } catch {}
let saveTimer;
function saveDb(){ clearTimeout(saveTimer); saveTimer=setTimeout(()=>{ const tmp=DB_FILE+".tmp"; fs.writeFile(tmp,JSON.stringify(db,null,2),err=>{ if(!err) fs.rename(tmp,DB_FILE,()=>{}); }); },100); }
function json(res,status,obj){res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});res.end(JSON.stringify(obj));}
function readBody(req){return new Promise((resolve,reject)=>{let data="";req.on("data",c=>{data+=c;if(data.length>12000){reject(new Error("Request too large"));req.destroy();}});req.on("end",()=>{try{resolve(JSON.parse(data||"{}"))}catch{reject(new Error("Invalid JSON"))}});req.on("error",reject);});}
function token(){return crypto.randomBytes(32).toString("hex");}
function publicUser(u){return {id:u.id,username:u.username,guest:!!u.guest,createdAt:u.createdAt,bestScore:u.bestScore||0,totalGames:u.totalGames||0,coins:u.coins||0,unlocks:u.unlocks||["starter"],equipped:u.equipped||"starter"};}
const SHOP_ITEMS=[{id:"starter",name:"Nova Scout",kind:"ship",price:0,color:"#7cf7ff",description:"Your trusty starter ship."},{id:"comet",name:"Comet Runner",kind:"ship",price:250,color:"#ff8fba",description:"Pink plasma wings."},{id:"nebula",name:"Nebula Ghost",kind:"ship",price:500,color:"#b5ff7d",description:"A mysterious green glow."},{id:"solar",name:"Solar Flare",kind:"ship",price:800,color:"#ffd36e",description:"Golden star-powered hull."},{id:"violet-trail",name:"Violet Trail",kind:"trail",price:350,color:"#c5a3ff",description:"A violet cosmic trail (visual preview)."},{id:"ice-trail",name:"Ice Trail",kind:"trail",price:450,color:"#82aaff",description:"An icy blue cosmic trail (visual preview)."}];
const itemById=id=>SHOP_ITEMS.find(x=>x.id===id);
function auth(req){const t=(req.headers.authorization||"").replace(/^Bearer\s+/i,"");const id=db.sessions[t];return id?db.users.find(u=>u.id===id):null;}
function newUser(username,guest=false){const now=new Date().toISOString();return {id:crypto.randomUUID(),username,guest,passwordSalt:null,passwordHash:null,createdAt:now,bestScore:0,totalGames:0,coins:0,unlocks:["starter"]};}
function issueSession(u){u.unlocks=u.unlocks||["starter"];u.equipped=u.equipped||"starter";u.coins=u.coins||0;const t=token();db.sessions[t]=u.id;saveDb();return t;}

const PUBLIC = path.join(__dirname, "public");
const W = 900, H = 600, MAX_ROOM = 100;
const server = http.createServer(async (req, res) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  let pathname; try { pathname = decodeURIComponent((req.url || "/").split("?")[0]); } catch { return json(res,400,{error:"Invalid URL."}); }
  if (pathname === "/healthz") return json(res,200,{ok:true,service:"meteor-dash-online"});
  if (pathname.startsWith("/api/") && !rateLimit(req,res, pathname==="/api/login" || pathname==="/api/register" ? 12 : 90)) return;
  if (pathname.startsWith("/api/")) {
    try {
      if (req.method === "POST" && pathname === "/api/guest") { const body=await readBody(req); let u=null; if(body.token && db.sessions[body.token]) u=db.users.find(x=>x.id===db.sessions[body.token]); if(!u){u=newUser("Guest-"+crypto.randomBytes(3).toString("hex").toUpperCase(),true);db.users.push(u);} const t=issueSession(u); return json(res,200,{token:t,user:publicUser(u)}); }
      if (req.method === "POST" && pathname === "/api/register") { const b=await readBody(req); const username=String(b.username||"").trim(); const password=String(b.password||""); if(!/^[A-Za-z0-9_]{3,16}$/.test(username))return json(res,400,{error:"Username must be 3–16 characters using letters, numbers, or underscores."}); if(password.length<8||password.length>128)return json(res,400,{error:"Password must be at least 8 characters."}); if(db.users.some(u=>u.username.toLowerCase()===username.toLowerCase()&&!u.guest))return json(res,409,{error:"That username is already taken."}); const salt=crypto.randomBytes(16).toString("hex");const hash=crypto.scryptSync(password,salt,64).toString("hex"); let u=null; if(b.token&&db.sessions[b.token]){u=db.users.find(x=>x.id===db.sessions[b.token]);} if(u&& !u.guest)return json(res,409,{error:"This session already belongs to an account."}); if(!u){u=newUser(username,false);db.users.push(u)} u.username=username;u.guest=false;u.passwordSalt=salt;u.passwordHash=hash;const t=issueSession(u);return json(res,201,{token:t,user:publicUser(u)}); }
      if (req.method === "POST" && pathname === "/api/login") { const b=await readBody(req);const username=String(b.username||"").trim();const password=String(b.password||"");const u=db.users.find(x=>!x.guest&&x.username.toLowerCase()===username.toLowerCase());if(!u||!u.passwordSalt||!crypto.timingSafeEqual(crypto.scryptSync(password,u.passwordSalt,64),Buffer.from(u.passwordHash,"hex")))return json(res,401,{error:"Incorrect username or password."});const t=issueSession(u);return json(res,200,{token:t,user:publicUser(u)}); }
      if (req.method === "GET" && pathname === "/api/me") { const u=auth(req);return u?json(res,200,{user:publicUser(u)}):json(res,401,{error:"Sign in required."}); }
      if (req.method === "GET" && pathname === "/api/leaderboard") return json(res,200,{leaderboard:db.leaderboard.slice(0,50)});
      if (req.method === "GET" && pathname === "/api/shop") { const u=auth(req); return json(res,200,{items:SHOP_ITEMS,user:u?publicUser(u):null,monetization:{realPayments:"not-configured",rewardedAds:"demo-only"}}); }
      if (req.method === "POST" && pathname === "/api/shop/buy") { const u=auth(req); if(!u)return json(res,401,{error:"Start a guest session or sign in first."}); const b=await readBody(req);const item=itemById(String(b.itemId||""));if(!item)return json(res,404,{error:"Item not found."});u.unlocks=u.unlocks||["starter"];if(u.unlocks.includes(item.id))return json(res,200,{user:publicUser(u),message:"You already own this item."});if((u.coins||0)<item.price)return json(res,400,{error:`You need ${item.price-(u.coins||0)} more coins.`});u.coins-=item.price;u.unlocks.push(item.id);u.equipped=item.id;saveDb();return json(res,200,{user:publicUser(u),message:`Unlocked ${item.name}!`}); }
      if (req.method === "POST" && pathname === "/api/shop/equip") { const u=auth(req);if(!u)return json(res,401,{error:"Start a guest session or sign in first."});const b=await readBody(req);const item=itemById(String(b.itemId||""));u.unlocks=u.unlocks||["starter"];if(!item||!u.unlocks.includes(item.id))return json(res,400,{error:"You do not own that item."});u.equipped=item.id;saveDb();return json(res,200,{user:publicUser(u),message:`Equipped ${item.name}.`}); }
      if (req.method === "POST" && pathname === "/api/rewards/ad") { const u=auth(req);if(!u)return json(res,401,{error:"Start a guest session or sign in first."});db.rewardClaims=db.rewardClaims||{};const now=Date.now(),last=db.rewardClaims[u.id]||0;if(now-last<60000)return json(res,429,{error:"Please wait before claiming another demo reward."});db.rewardClaims[u.id]=now;u.coins=(u.coins||0)+50;saveDb();return json(res,200,{user:publicUser(u),message:"Demo reward: +50 coins. A real rewarded ad SDK is not connected yet."}); }
      if (req.method === "GET" && pathname === "/api/store-products") return json(res,200,{products:[],configured:false,message:"Real-money products are not configured. Connect Apple StoreKit and Google Play Billing and verify purchases on the server before enabling payments."});
      if (req.method === "POST" && pathname === "/api/score") { const u=auth(req);if(!u)return json(res,401,{error:"Sign in or play as a guest to save scores."});const b=await readBody(req);const score=Math.max(0,Math.min(100000,Math.floor(Number(b.score)||0)));u.totalGames=(u.totalGames||0)+1;u.coins=(u.coins||0)+Math.floor(score/10);u.bestScore=Math.max(u.bestScore||0,score);const old=db.leaderboard.find(x=>x.userId===u.id);if(old){old.username=u.username;old.bestScore=u.bestScore;old.updatedAt=new Date().toISOString()}else db.leaderboard.push({userId:u.id,username:u.username,bestScore:u.bestScore,updatedAt:new Date().toISOString()});db.leaderboard.sort((a,b)=>b.bestScore-a.bestScore);db.leaderboard=db.leaderboard.slice(0,500);saveDb();return json(res,200,{user:publicUser(u),leaderboard:db.leaderboard.slice(0,50)}); }
      if (req.method === "POST" && pathname === "/api/oauth-not-configured") return json(res,501,{error:"Apple/Google sign-in requires developer credentials and provider setup. See SETUP.md."});
      return json(res,404,{error:"API route not found."});
    } catch(e) { return json(res,400,{error:e.message||"Request failed."}); }
  }
  const file = path.normalize(path.join(PUBLIC, pathname === "/" ? "index.html" : pathname));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(file);
    res.writeHead(200, {"Content-Type": ext === ".html" ? "text/html; charset=utf-8" : ext === ".css" ? "text/css; charset=utf-8" : "text/javascript; charset=utf-8", "Cache-Control":"no-store"});
    res.end(data);
  });
});
const wss = new WebSocket.Server({server, maxPayload: 2048});
const players = new Map(), rooms = new Map();
let idCounter = 1, meteorCounter = 1;
const palette = ["#7cf7ff","#ff8fba","#b5ff7d","#ffd36e","#c5a3ff","#ff9d6f","#82aaff"];
const modes = ["race","private","royale"];
const roomCode = () => crypto.randomBytes(3).toString("hex").toUpperCase();
const cleanName = s => String(s || "Pilot").replace(/[<>]/g,"").trim().slice(0,16) || "Pilot";
const send = (p, o) => { if (p?.ws.readyState === WebSocket.OPEN) p.ws.send(JSON.stringify(o)); };
function createRoom(mode, isPrivate=false) {
  let code; do { code = roomCode(); } while (rooms.has(code));
  const room = {code, mode, isPrivate, players:new Set(), meteors:[], lastMeteor:0, startedAt:Date.now(), roundOver:false, winner:null};
  rooms.set(code,room); return room;
}
function roomFor(p) { return rooms.get(p.room); }
function roomState(room) {
  return {type:"state", room:room.code, mode:room.mode, roundOver:room.roundOver, winner:room.winner,
    players:[...room.players].map(id=>players.get(id)).filter(Boolean).map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,score:p.score,alive:p.alive,color:p.cosmeticColor||p.color})),
    meteors:room.meteors};
}
function broadcastRoom(room, o) { for (const id of room.players) send(players.get(id),o); }
function leaveRoom(p) {
  const room=roomFor(p); if (!room) return;
  room.players.delete(p.id);
  broadcastRoom(room,{type:"notice",text:`${p.name} left the room.`});
  if (!room.players.size) rooms.delete(room.code);
  else updateRoyaleWinner(room);
  p.room=null;
}
function joinRoom(p, room) {
  if (room.players.size>=MAX_ROOM) { send(p,{type:"error",message:"That room is full."}); return false; }
  if (p.room) leaveRoom(p);
  room.players.add(p.id); p.room=room.code;
  p.x=100+Math.random()*(W-200); p.y=H-80; p.score=0; p.alive=true;
  room.roundOver=false; room.winner=null;
  send(p,{type:"joined",id:p.id,room:room.code,mode:room.mode,width:W,height:H});
  broadcastRoom(room,{type:"notice",text:`${p.name} joined ${room.mode==="private"?"the private room":room.mode==="royale"?"the battle royale":"the survival race"}.`});
  broadcastRoom(room,roomState(room));
  return true;
}
function updateRoyaleWinner(room) {
  if(room.mode!=="royale" || room.roundOver) return;
  const alive=[...room.players].map(id=>players.get(id)).filter(p=>p&&p.alive);
  const total=room.players.size;
  if(total>=2 && alive.length<=1) {
    room.roundOver=true; room.winner=alive[0]?.name || "No one";
    broadcastRoom(room,{type:"roundover",winner:room.winner});
  }
}
wss.on("connection",ws=>{
  const id=String(idCounter++);
  const p={id,ws,name:"Pilot",x:W/2,y:H-80,score:0,alive:true,color:palette[Math.floor(Math.random()*palette.length)],room:null,lastInput:0,lastRestart:0};
  players.set(id,p);
  send(p,{type:"welcome",id,width:W,height:H});
  ws.on("message",raw=>{
    let m; try{m=JSON.parse(raw.toString())}catch{return}
    if(!m||typeof m.type!=="string")return;
    if(m.type==="hello"){p.name=cleanName(m.name); if(typeof m.token==="string"&&db.sessions[m.token]){const u=db.users.find(x=>x.id===db.sessions[m.token]);if(u){p.userId=u.id;p.name=u.username;const equipped=itemById(u.equipped||"starter");p.cosmeticColor=equipped?.color||palette[0];}}}
    if(m.type==="join"){
      const mode=m.mode;
      if(!modes.includes(mode)){send(p,{type:"error",message:"Unknown game mode."});return;}
      if(mode==="private"){
        const code=String(m.code||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,6);
        let room=rooms.get(code);
        if(!room || room.mode!=="private"){send(p,{type:"error",message:"Private room not found. Create a room first."});return;}
        joinRoom(p,room);
      } else if(mode==="race") {
        let room=[...rooms.values()].find(r=>r.mode==="race"&&!r.isPrivate&&r.players.size<MAX_ROOM&&!r.roundOver);
        if(!room)room=createRoom("race");
        joinRoom(p,room);
      } else {
        let room=[...rooms.values()].find(r=>r.mode==="royale"&&!r.isPrivate&&r.players.size<MAX_ROOM&&!r.roundOver);
        if(!room)room=createRoom("royale");
        joinRoom(p,room);
      }
    }
    if(m.type==="createPrivate"){
      const room=createRoom("private",true); joinRoom(p,room);
      send(p,{type:"privateCreated",code:room.code});
    }
    if(m.type==="move"){
      const now=Date.now(); if(now-p.lastInput<25)return; p.lastInput=now;
      if(!p.room||!p.alive||!Number.isFinite(m.x)||!Number.isFinite(m.y))return;
      p.x=Math.max(18,Math.min(W-18,m.x)); p.y=Math.max(70,Math.min(H-24,m.y));
    }
    if(m.type==="restart"){
      const now=Date.now();if(now-p.lastRestart<1000)return;p.lastRestart=now;
      const r=roomFor(p);if(!r)return;
      p.x=100+Math.random()*(W-200);p.y=H-80;p.score=0;p.alive=true;
      if(r.mode==="royale"){r.roundOver=false;r.winner=null;}
      broadcastRoom(r,roomState(r));
    }
  });
  ws.on("close",()=>{leaveRoom(p);players.delete(id);});
});

setInterval(()=>{
  const now=Date.now();
  for(const room of rooms.values()){
    if(!room.players.size)continue;
    if(now-room.lastMeteor>(room.mode==="royale"?360:650)){
      room.lastMeteor=now;
      room.meteors.push({id:meteorCounter++,x:18+Math.random()*(W-36),y:-24,r:10+Math.random()*13,vy:2.2+Math.random()*2.5});
    }
    room.meteors=room.meteors.filter(m=>m.y<H+35);
    for(const m of room.meteors){
      m.y+=m.vy;
      for(const id of room.players){
        const p=players.get(id);if(!p||!p.alive||room.roundOver)continue;
        const dx=p.x-m.x,dy=p.y-m.y;
        if(dx*dx+dy*dy<(m.r+13)**2){p.alive=false;send(p,{type:"gameover",score:p.score});if(p.userId){const u=db.users.find(x=>x.id===p.userId);if(u){u.totalGames=(u.totalGames||0)+1;u.coins=(u.coins||0)+Math.floor(p.score/10);u.bestScore=Math.max(u.bestScore||0,p.score);let row=db.leaderboard.find(x=>x.userId===u.id);if(!row){row={userId:u.id,username:u.username,bestScore:u.bestScore,updatedAt:new Date().toISOString()};db.leaderboard.push(row)}else{row.username=u.username;row.bestScore=u.bestScore;row.updatedAt=new Date().toISOString()}db.leaderboard.sort((a,b)=>b.bestScore-a.bestScore);db.leaderboard=db.leaderboard.slice(0,500);saveDb();send(p,{type:"profile",user:publicUser(u)});}}}
      }
    }
    for(const id of room.players){const p=players.get(id);if(p&&p.alive&&!room.roundOver)p.score++;}
    updateRoyaleWinner(room);
    broadcastRoom(room,roomState(room));
  }
},50);
server.listen(PORT,HOST,()=>console.log(`Meteor Dash Online running on ${HOST}:${PORT}`));
