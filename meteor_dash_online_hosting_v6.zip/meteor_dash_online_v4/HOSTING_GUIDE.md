# Host Meteor Dash Online (Render)

This project can be hosted online, but I cannot create the cloud service under your account without your account authorization and setup. This guide gets you to a public test deployment.

## Before starting
- A GitHub account
- A Render account
- Note: the included Render blueprint uses a paid Starter web service and a persistent disk. Check current pricing before creating it. A free ephemeral service is not suitable for keeping this JSON-file account database reliably.

## Deploy steps
1. Extract this ZIP on a computer.
2. Create a new GitHub repository for the project.
3. Upload the **contents** of the `meteor_dash_online_v4` folder to the repository root. If you keep the folder nested, edit `rootDir` in `render.yaml` to match the folder path or move `render.yaml` to the repository root and set `rootDir: .`.
4. In Render, choose **New → Blueprint** and connect the repository containing `render.yaml`.
5. Review the service and persistent-disk plan and confirm creation. Render will build with `npm install && npm run check`, start with `npm start`, and check `/healthz`.
6. When Render reports the service is live, open its `https://...onrender.com` URL. Check that `/healthz` returns JSON containing `"ok":true`.
7. Open the game on two devices/browsers and test guest login, room codes, each game mode, scoring, shop purchases with demo coins, and leaderboard updates.

## Important deployment notes
- The server supports `DATA_FILE` so the database JSON can live on the persistent disk at `/var/data/data.json`.
- This is a public **test deployment**, not a production-ready commercial launch. JSON-file storage is not robust for multiple server instances or high traffic; use a managed database and migration before scaling.
- Apple/Google OAuth, real billing, receipt validation, real rewarded ads, account recovery/deletion, and native app builds are not implemented. Do not accept real money or advertise the simulated reward button as a real ad.
- Use a strong secret/session design, backups, monitoring, anti-cheat and load/security testing before public release. Never put passwords, API keys, or signing credentials in the repository.
- Check Render's current service/disk pricing and terms before confirming deployment.
