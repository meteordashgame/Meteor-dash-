# Privacy Policy — Template (must be completed before release)

**Last updated:** [DATE]  
**Operator:** [LEGAL NAME / BUSINESS]  
**Contact:** [SUPPORT EMAIL]  
**Website:** [PUBLIC HTTPS URL]

This template is not legal advice and is not ready to publish until every bracketed field is completed and it accurately reflects the shipped app and its vendors.

## Information we collect
Depending on enabled features, Meteor Dash may process usernames, password hashes, account/session identifiers, game scores, coins and cosmetic inventory, multiplayer room activity, basic technical logs, and information processed by sign-in, hosting, analytics, advertising, and payment providers. List every field and provider actually used before publishing.

## How we use information
We use information to operate accounts, save game progress, provide multiplayer and leaderboards, prevent abuse, process purchases, deliver opted-in ads/rewards, provide support, and maintain service security.

## Sharing
We may share necessary information with hosting, database, identity, payment, analytics, and advertising providers. Identify each provider, link its privacy notice, and describe any cross-context advertising or sale/sharing practices as applicable under law.

## Retention and deletion
Describe retention periods and the exact account deletion/data request process. Provide a working contact and implement the process before launch.

## Children and parental controls
[Describe the intended age range, applicable age-screening approach, parental consent, and child-directed advertising/data practices. Do not launch with ads or tracking until applicable child-privacy obligations are assessed.]

## Security
Describe safeguards accurately; no internet service can guarantee absolute security. Do not claim encryption or controls that are not implemented.

## International transfers and rights
[Describe relevant jurisdictions, legal bases where applicable, privacy rights, and how users exercise them.]

## Changes and contact
We may update this policy and will post the effective date here. Contact [SUPPORT EMAIL] with privacy questions.
