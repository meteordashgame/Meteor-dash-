# Terms of Service — Template (must be completed before release)

**Effective date:** [DATE]  
**Operator:** [LEGAL NAME / BUSINESS]  
**Contact:** [SUPPORT EMAIL]

This is a starter template, not legal advice. Have qualified counsel adapt it to your business, regions, age range, monetization, and actual game behavior before publishing.

## Eligibility and accounts
[Set minimum age, guardian-consent rules, account responsibilities, recovery process, and prohibited usernames.] Do not collect unnecessary personal information. You may suspend accounts for cheating, fraud, harassment, or security abuse under a clear appeals process.

## Gameplay and virtual items
Virtual coins and cosmetics are digital items with no cash value and may not be transferable unless expressly stated. Explain whether items are purchased, earned, refundable, consumable, or subject to changes. Do not promise permanent availability unless intended.

## Purchases and refunds
Purchases are processed by the applicable app store/payment provider. Explain restore purchases, refunds, cancellations, taxes, and regional rules. Nothing in these terms limits non-waivable consumer rights.

## Fair play and service availability
Prohibit cheating, exploitation, harassment, and interference with service. Explain that online features may be interrupted and how reports are handled.

## Intellectual property
Describe ownership/licensing of game assets and permitted use. Ensure all assets and third-party components are properly licensed.

## Disclaimers, liability, termination, and disputes
[Have counsel draft provisions compliant with each target jurisdiction, including mandatory consumer protections.] Do not publish an unreviewed liability waiver.

## Contact and changes
Contact [SUPPORT EMAIL]. Post changes with an updated effective date and provide notice where required.
